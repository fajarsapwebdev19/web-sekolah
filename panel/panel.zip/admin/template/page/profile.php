<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- .row -->
            <div class="row">
                <!-- .col-md-4 -->
                <div class="col-md-4 mt-4 mb-4 user-profile-detail">
                    <div class="card">
                        <div class="card-body">
                            <div id="profile-detail">
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.col-md-4 -->
                <!-- .col-md-10 -->
                <div class="col-md-8 mt-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="success-msg">
                                <div class="alert" id="custom-message">
                                    <div class="msg">

                                    </div>
                                </div>
                            </div>
                            <div id="form-user-edit">

                            </div>
                        </div>
                    </div>
                </div>
                <!-- .col-md-10 -->
            </div>
            <!-- /.row -->
        </div>
        <!--/. container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->