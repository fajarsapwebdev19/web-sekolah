<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <style>
        .error-page{
            padding-top: 80px!important;
            padding-bottom: 80px!important;
        }
    </style>
    <section class="content error-page">
      <div class="error-page">
        <h2 class="headline text-warning"> 404</h2>

        <div class="error-content mt-4">
          <h3><i class="fas fa-exclamation-triangle text-warning"></i> Oops! Halaman Yang Anda Masukan Tidak Di Temukan</h3>

          <p>
            Silahkan Cari Halaman Url Yang Valid
          </p>
        </div>
        <!-- /.error-content -->
      </div>
      <!-- /.error-page -->
    </section>
    <!-- /.content -->
  </div>