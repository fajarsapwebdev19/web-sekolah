<?php
  require '../../connection/connect.php';
  session_start();

  if(isset($_POST['tambah']))
  {
    $id = mt_rand();
    $nama = mysqli_real_escape_string($con, $_POST['nama']);
    $jenis_kelamin = mysqli_real_escape_string($con, $_POST['jenis_kelamin']);
    $tempat_lahir = mysqli_real_escape_string($con, $_POST['tempat_lahir']);
    $tanggal_lahir = mysqli_real_escape_string($con, date('Y-m-d', strtotime($_POST['tanggal_lahir'])));
    $asal_instansi = mysqli_real_escape_string($con, $_POST['asal_instansi']);
    $jabatan = mysqli_real_escape_string($con, $_POST['jabatan']);
    
    // jika ada user jail matiin validasi yang ada di depan layar
    if(empty($_FILES['foto']['name']))
    {
      $_SESSION['val'] = '<div class="alert alert-danger" id="auto-close">
        <em class="fas fa-info-circle"></em> Foto Kosong
      </div>';
      header('location: ../?page=anggota');
    }
    else
    {
      $foto = $_FILES['foto']['name'];
      $tmp_foto = $_FILES['foto']['tmp_name'];
      $size = $_FILES['foto']['size'];
      $ekstensi = array("jpg","jpeg","png");
      $ex = pathinfo($foto, PATHINFO_EXTENSION);

      // validasi ekstensi file
      if(!in_array($ex, $ekstensi))
      {
        $_SESSION['val'] = '<div class="alert alert-warning" id="auto-close">
          <em class="fas fa-info-circle"></em> Ekstensi file yang di izinkan hanya jpg,jpeg dan png
        </div>';
        header('location: ../?page=anggota');
      }
      else
      {
        // validasi ukuran file
        // maximal 5 MB
        if($size >= 5000000)
        {
          $_SESSION['val'] = '<div class="alert alert-danger" id="auto-close">
            <em class="fas fa-info-circle"></em> Ukuran file lebih dari 5 MB
          </div>';
        header('location: ../?page=anggota');
        }
        else
        {
          // eksekusi upload file
          // tempat naruh file foto
          $dir = "../../../assets/galeri/foto/anggota/".$foto;

          move_uploaded_file($tmp_foto, $dir);

          $by = $_SESSION['username'];
          $date = date('Y-m-d');

          // simpan data ke database
          $tambah = mysqli_query($con, "INSERT INTO anggota VALUES ('$id','$foto','$nama','$jenis_kelamin','$tempat_lahir', '$tanggal_lahir', '$asal_instansi', '$jabatan', '$date', '$by', NULL, NULL)");

          if($tambah)
          {
            $_SESSION['val'] = '<div class="alert alert-success" id="auto-close">
              <em class="fas fa-check-circle"></em> Tambah anggota berhasil
            </div>';
            header('location: ../?page=anggota');
          }
        }
      }
    }
  }
  else if(isset($_POST['ubah']))
  {
    if(isset($_POST['id']))
    {
      $id = mysqli_real_escape_string($con, $_POST['id']);
      $nama = mysqli_real_escape_string($con, $_POST['nama']);
      $jenis_kelamin = mysqli_real_escape_string($con, $_POST['jenis_kelamin']);
      $tempat_lahir = mysqli_real_escape_string($con, $_POST['tempat_lahir']);
      $tanggal_lahir = mysqli_real_escape_string($con, date('Y-m-d', strtotime($_POST['tanggal_lahir'])));
      $asal_instansi = mysqli_real_escape_string($con, $_POST['asal_instansi']);
      $jabatan = mysqli_real_escape_string($con, $_POST['jabatan']);
      $date = date('Y-m-d');
      $by = $_SESSION['username'];

      // jika user tidak melakukan upload file maka sistem merubah data tidak beserta foto
      if(empty($_FILES['foto']['name']))
      {
        $update = mysqli_query($con, "UPDATE anggota SET nama='$nama',jk='$jenis_kelamin',tempat_lahir='$tempat_lahir', tgl_lahir='$tanggal_lahir', asal_instansi='$asal_instansi', jabatan='$jabatan', modified_date='$date', modified_by='$by' WHERE id_anggota='$id'");
      }
      else
      {
        $foto = $_FILES['foto']['name'];
        $tmp_foto = $_FILES['foto']['tmp_name'];
        $size = $_FILES['foto']['size'];
        $ekstensi = array("jpg","jpeg","png");
        $ex = pathinfo($foto, PATHINFO_EXTENSION);

        // validasi ekstensi file
        if(!in_array($ex, $ekstensi))
        {
          $_SESSION['val'] = '<div class="alert alert-warning" id="auto-close">
            <em class="fas fa-info-circle"></em> Ekstensi file yang di izinkan hanya jpg,jpeg dan png
          </div>';
          header('location: ../?page=anggota');
        }
        else
        {
          // validasi ukuran file
          // maximal 5 MB
          if($size >= 5000000)
          {
            $_SESSION['val'] = '<div class="alert alert-danger" id="auto-close">
              <em class="fas fa-info-circle"></em> Ukuran file lebih dari 5 MB
            </div>';
          header('location: ../?page=anggota');
          }
          else
          {
            // hapus gambar lama
            $query = mysqli_query($con, "SELECT * FROM anggota WHERE id_anggota='$id'");

            $data = mysqli_fetch_object($query);

            if(file_exists("../../../assets/galeri/foto".$data->foto))
            {
              unlink("../../../assets/galeri/foto".$data->foto);
            }

            // rename file dan simpan file baru
            $rename = mt_rand().'__'.$foto;
            $dir = "../../../assets/galeri/foto/anggota/".$rename;

            move_uploaded_file($tmp_foto, $dir);

            $update = mysqli_query($con, "UPDATE anggota SET foto='$rename', nama='$nama',jk='$jenis_kelamin',tempat_lahir='$tempat_lahir', tgl_lahir='$tanggal_lahir', asal_instansi='$asal_instansi', jabatan='$jabatan', modified_date='$date', modified_by='$by' WHERE id_anggota='$id'");
          }
        }
      }
        if($update)
        {
          $_SESSION['val'] = '<div class="alert alert-success" id="auto-close">
            <em class="fas fa-check-circle"></em> Tambah anggota berhasil
          </div>';
          header('location: ../?page=anggota');
        }
    }
  }
  else if(isset($_POST['hapus']))
  {
    $id = mysqli_real_escape_string($con, $_POST['id']);

    // hapus foto dari folder local
    // cari data di database
    $query = mysqli_query($con, "SELECT * FROM anggota WHERE id_anggota='$id'");
    $data = mysqli_fetch_object($query);

    if(file_exists("../../../assets/galeri/foto/anggota/".$data->foto))
    {
      unlink("../../../assets/galeri/foto/anggota/".$data->foto);
    }

    // eksekusi hapus data anggota by id
    $delete = mysqli_query($con, "DELETE FROM anggota WHERE id_anggota='$id'");

    if($delete)
    {
      $_SESSION['val'] = '<div class="alert alert-success" id="auto-close">
        <em class="fas fa-check-circle"></em> Hapus anggota berhasil
      </div>';
      header('location: ../?page=anggota');
    }
  }
  
?>