 id="auto-close"<?php
  require '../../connection/connect.php';
  session_start();
  if(isset($_POST['tambah']))
  {
    $id = mt_rand();
    $judul_video = mysqli_real_escape_string($con, $_POST['judul_video']);
    $video = $_FILES['video']['name'];
    $tmp_video = $_FILES['video']['tmp_name'];
    $ex = array("mp4", "3gp", "avi");
    $extension = pathinfo($video, PATHINFO_EXTENSION);

    if(empty($_FILES['video']['name']))
    {
      $_SESSION['val'] = '<div class="alert alert-danger" id="auto-close">
        <em class="fas fa-info-circle"></em> Video Kosong
      </div>';
      header('location: ../?page=galery_video');
    }
    else
    {
      // validasi extension
      if(!in_array($extension, $ex))
      {
        $_SESSION['val'] = '<div class="alert alert-warning" id="auto-close">
          <em class="fas fa-info-circle"></em> Ekstensi yang di izinkan hanya mp4,3gp, dan avi
        </div>';
        header('location: ../?page=galery_video');
      }
      else
      {
        // validasi ukuran file
        // batas max file upload 2 GB
        if($size >= 2000000000)
        {
            $_SESSION['val'] = '<div class="alert alert-danger" id="auto-close">
              <em class="fas fa-info-circle"></em> Ukuran File melebihi dari 2 GB
            </div>';
            header('location: ../?page=galery_video');
        }
        else
        {
          // eksekusi upload video
          // tempat naruh file 
          $dir = "../../../assets/galeri/video/".$video;

          move_uploaded_file($tmp_video, $dir);

          $date = date('Y-m-d');
          $cdate = $date;
          $by = $_SESSION['username'];

          $tambah = mysqli_query($con, "INSERT INTO video_upload VALUES ('$id','$judul_video','$video','$date','$cdate','$by',NULL,NULL)");

          if($tambah)
          {
            $_SESSION['val'] = '<div class="alert alert-success" id="auto-close">
              <em class="fas fa-check-circle"></em> Upload Video Berhasil
            </div>';
            header('location: ../?page=galery_video');
          }
        }
      }
    }
  }
  else if(isset($_POST['ubah']))
  {
    if(isset($_POST['id']))
    {
      $id = mysqli_real_escape_string($con, $_POST['id']);
      $date = date('Y-m-d');
      $by = $_SESSION['username'];
      $judul_video = mysqli_real_escape_string($con, $_POST['judul_video']);

      // jika user tidak melakukan perubahan video maka yang dirubah hanya judul video saja
      if(empty($_FILES['video']['name']))
      {
        $update = mysqli_query($con, "UPDATE video_upload SET judul_file='$judul_video', modified_date='$date', modified_by='$by' WHERE id_video='$id'");
      }
      else{
        // jika user melakukan perubahan video maka akan dilakukan validasi terlebih dahulu
        $video = $_FILES['video']['name'];
        $tmp_video = $_FILES['video']['tmp_name'];
        $size = $_FILES['video']['size'];
        $ex = pathinfo($video, PATHINFO_EXTENSION);
        $extension = array("mp4","3gp","avi");
        
        // validasi ekstensi
        if(!in_array($ex, $extension))
        {
          $_SESSION['val'] = '<div class="alert alert-warning" id="auto-close">
            <em class="fas fa-info-circle"></em> Ekstensi file yang di izinkan hanya mp4,3gp,dan avi
          </div>';
          header('location: ../?page=galery_video');
        }else{
          // validasi ukuran
          // max 2GB
          if($size >= 2000000000)
          {
            $_SESSION['val'] = '<div class="alert alert-danger" id="auto-close">
              <em class="fas fa-info-circle"></em> Ukuran file lebih dari 2 GB
            </div>';
            header('location: ../?page=galery_video');
          }else{
            // hapus file lama dari folder local
            // cari data di database
            $query = mysqli_query($con, "SELECT * FROM video_upload WHERE id_video='$id'");
            $data = mysqli_fetch_object($query);

            if(file_exists("../../../assets/galeri/video/".$data->file))
            {
              unlink("../../../assets/galeri/video/".$data->file);
            }

            // eksekusi upload file baru
            // tempat file baru
            $rename = mt_rand().'__'.$video; //rename video
            $dir = "../../../assets/galeri/video/".$rename;

            $update = mysqli_query($con, "UPDATE video_upload SET judul_file='$judul_video', file='$rename', modified_date='$date', modified_by='$by' WHERE id_video='$id'");
          }
        }
      }

      if($update)
      {
        $_SESSION['val'] = '<div class="alert alert-success" id="auto-close">
          <em class="fas fa-check-circle"></em> Berhasil Ubah Video
        </div>';
        header('location: ../?page=galery_video');
      }
    }
  }
  else if(isset($_POST['hapus']))
  {
    $id = mysqli_real_escape_string($con, $_POST['id']);

    // hapus file lama dari folder local
    // cari data di database
    $query = mysqli_query($con, "SELECT * FROM video_upload WHERE id_video='$id'");
    $data = mysqli_fetch_object($query);

    if(file_exists("../../../assets/galeri/video/".$data->file))
    {
      unlink("../../../assets/galeri/video/".$data->file);
    }

    $delete = mysqli_query($con, "DELETE FROM video_upload WHERE id_video='$id'");

    if($delete)
    {
      $_SESSION['val'] = '<div class="alert alert-success" id="auto-close">
          <em class="fas fa-check-circle"></em> Berhasil Hapus Video
      </div>';
      header('location: ../?page=galery_video');
    }
  }
?>